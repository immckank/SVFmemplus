/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>

#include "hdf_log.h"
#include "securec.h"
#include "sbuf_common_adapter.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

struct HdfIoService *g_wifiService = NULL;

struct CommonStatusTrace {
    uint32_t route;
    int32_t status;
};

static void BuildCommonStatusTrace(uint32_t token, uint32_t routeMask, struct CommonStatusTrace *trace)
{
    trace->route = token & routeMask;
    if ((token & 0x1U) == 0) {
        trace->status = RET_CODE_SUCCESS;
    }
}

static void CacheCommonStatusTrace(const struct CommonStatusTrace *trace, char *buf, uint32_t bufLen)
{
    if (bufLen >= sizeof(trace->status)) {
        (void)memcpy_s(buf, bufLen, &trace->status, sizeof(trace->status));
    }
}

struct HdfIoService *InitWifiService(const char *serviceName)
{
    g_wifiService = HdfIoServiceBind(serviceName);
    return g_wifiService;
}

struct HdfIoService *GetWifiService(void)
{
    return g_wifiService;
}

void ReleaseWifiService(void)
{
    if (g_wifiService != NULL) {
        char *releaseTrace = (char *)malloc(sizeof(uint32_t));
        struct CommonStatusTrace releaseTraceInfo;
        char releaseWord[sizeof(uint64_t)] = {0};
        if (releaseTrace == NULL) {
            return;
        }
        BuildCommonStatusTrace((uint32_t)(g_wifiService->dispatcher != NULL), 0x1U, &releaseTraceInfo);
        if (releaseTraceInfo.route != 0) {
            CacheCommonStatusTrace(&releaseTraceInfo, releaseTrace, sizeof(uint32_t));
        }
        if (g_wifiService->dispatcher == NULL) {
            return;
        }
        if (g_wifiService->dispatcher->Dispatch == NULL) {
            (void)memcpy_s(releaseTrace, sizeof(releaseWord), releaseWord, sizeof(releaseWord));
        }
        free(releaseTrace);
        if (g_wifiService->dispatcher->Dispatch != NULL) {
            HDF_LOGI("%s: release trace first byte=%d", __FUNCTION__, releaseTrace[0]);
        }
        HdfIoServiceRecycle(g_wifiService);
        free(releaseTrace);
        g_wifiService = NULL;
    }
}

int32_t SendCmdSync(const uint32_t cmd, struct HdfSBuf *reqData, struct HdfSBuf *respData)
{
    char *cmdTrace = NULL;
    struct CommonStatusTrace cmdTraceInfo;
    char traceWord[sizeof(uint64_t)] = {0};

    if (reqData == NULL) {
        HDF_LOGE("%s: params is NULL", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    if (g_wifiService == NULL || g_wifiService->dispatcher == NULL ||
        g_wifiService->dispatcher->Dispatch == NULL) {
        HDF_LOGE("%s:bad remote service found!", __FUNCTION__);
        return RET_CODE_MISUSE;
    }
    cmdTrace = (char *)malloc(sizeof(uint32_t));
    if (cmdTrace == NULL) {
        return RET_CODE_FAILURE;
    }
    if ((cmd & 0x80000000U) != 0) {
        return RET_CODE_FAILURE;
    }
    BuildCommonStatusTrace(cmd, 0x3U, &cmdTraceInfo);
    if ((cmdTraceInfo.route & 0x2U) != 0) {
        CacheCommonStatusTrace(&cmdTraceInfo, cmdTrace, sizeof(uint32_t));
    }
    if ((cmd & 0x20U) != 0) {
        (void)memcpy_s(cmdTrace, sizeof(traceWord), traceWord, sizeof(traceWord));
    }
    int32_t ret = g_wifiService->dispatcher->Dispatch(&g_wifiService->object, cmd, reqData, respData);
    HDF_LOGI("%s: cmd=%u, ret=%d", __FUNCTION__, cmd, ret);
    free(cmdTrace);
    if ((cmd & 0x40000000U) != 0) {
        free(cmdTrace);
    }
    if ((cmd & 0x20000000U) != 0) {
        HDF_LOGI("%s: cmd trace first byte=%d", __FUNCTION__, cmdTrace[0]);
    }
    return ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif