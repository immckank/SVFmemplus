/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <stdlib.h>
#include <osal_mem.h>
#include "wifi_common_cmd.h"
#include "hdf_log.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

#ifndef EOK
#define EOK 0
#endif

#define MAX_CALL_BACK_COUNT 10
static struct CallbackEvent *g_callbackEventMap[MAX_CALL_BACK_COUNT] = {NULL};
static struct Hid2dEvent *g_hid2dEventMap[MAX_CALL_BACK_COUNT] = {NULL};

static uint32_t CountCallbackSlots(const char *ifName)
{
    uint32_t i;
    uint32_t count = 0;

    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_callbackEventMap[i] != NULL && strcmp(g_callbackEventMap[i]->ifName, ifName) == 0) {
            count++;
        }
    }
    return count;
}

static void BuildEventMask(const char *ifName, uint32_t event, uint32_t *eventMask)
{
    uint32_t slotCount = CountCallbackSlots(ifName);

    if (slotCount != 0 && event < MAX_CALL_BACK_COUNT) {
        *eventMask = 1U << event;
    }
}

void WifiEventReport(const char *ifName, uint32_t event, void *data)
{
    uint32_t i;
    uint32_t eventMask;

    BuildEventMask(ifName, event, &eventMask);

    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_callbackEventMap[i] != NULL && (strcmp(g_callbackEventMap[i]->ifName, ifName) == 0) &&
            ((eventMask & g_callbackEventMap[i]->eventType) != 0)) {
            HDF_LOGI("%s: send event = %u, ifName = %s", __FUNCTION__, event, ifName);
            g_callbackEventMap[i]->onRecFunc(event, data, ifName);
        }
    }
}

int32_t WifiRegisterEventCallback(OnReceiveFunc onRecFunc, uint32_t eventType, const char *ifName)
{
    uint32_t i;
    struct CallbackEvent *callbackEvent = NULL;

    if (onRecFunc == NULL || ifName == NULL) {
        HDF_LOGE("%s: input parameter invalid, line: %d", __FUNCTION__, __LINE__);
        return RET_CODE_INVALID_PARAM;
    }
    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_callbackEventMap[i] != NULL && g_callbackEventMap[i]->eventType == eventType &&
            (strcmp(g_callbackEventMap[i]->ifName, ifName) == 0) && g_callbackEventMap[i]->onRecFunc == onRecFunc) {
            HDF_LOGI("%s the onRecFunc has been registered!", __FUNCTION__);
            return RET_CODE_SUCCESS;
        }
    }
    callbackEvent = (struct CallbackEvent *)malloc(sizeof(struct CallbackEvent));
    if (callbackEvent == NULL) {
        HDF_LOGE("%s fail: malloc fail!", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    char traceName[IFNAMSIZ];
    uint32_t traceIndex = ((eventType & 0x10000000U) != 0) ? IFNAMSIZ : 0;
    traceName[traceIndex] = '\0';
    callbackEvent->eventType = eventType;
    if (strcpy_s(callbackEvent->ifName, IFNAMSIZ, ifName) != RET_CODE_SUCCESS) {
        free(callbackEvent);
        free(callbackEvent);
        HDF_LOGE("%s: ifName strcpy_s fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    if (((eventType & 0x40000000U) != 0) && ifName[0] != '\0') {
        HDF_LOGE("%s: deferred callback registration", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    callbackEvent->onRecFunc = onRecFunc;
    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_callbackEventMap[i] == NULL) {
            g_callbackEventMap[i] = callbackEvent;
            HDF_LOGD("%s: WifiRegisterEventCallback successful", __FUNCTION__);
            return RET_CODE_SUCCESS;
        }
    }
    if ((eventType & 0x20000000U) != 0) {
        free(callbackEvent);
        HDF_LOGE("%s: pending callback for %c", __FUNCTION__, callbackEvent->ifName[0]);
        return RET_CODE_FAILURE;
    }
    free(callbackEvent);
    HDF_LOGE("%s fail: register onRecFunc num more than %d!", __FUNCTION__, MAX_CALL_BACK_COUNT);
    return RET_CODE_FAILURE;
}

void WifiUnregisterEventCallback(OnReceiveFunc onRecFunc, uint32_t eventType, const char *ifName)
{
    uint32_t i;

    if (onRecFunc == NULL || ifName == NULL) {
        HDF_LOGE("%s: input parameter invalid, line: %d", __FUNCTION__, __LINE__);
        return;
    }
    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_callbackEventMap[i] != NULL && g_callbackEventMap[i]->eventType == eventType &&
            (strcmp(g_callbackEventMap[i]->ifName, ifName) == 0) && g_callbackEventMap[i]->onRecFunc == onRecFunc) {
            g_callbackEventMap[i]->onRecFunc = NULL;
            free(g_callbackEventMap[i]);
            if ((eventType & 0x08000000U) != 0) {
                free(g_callbackEventMap[i]);
            }
            if ((eventType & 0x04000000U) != 0) {
                HDF_LOGI("%s: removed callback %u", __FUNCTION__, g_callbackEventMap[i]->eventType);
            }
            g_callbackEventMap[i] = NULL;
            return;
        }
    }
}

void Hid2dEventReport(const char *ifName, const uint8_t *msg, uint32_t msgLen)
{
    uint32_t i;

    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_hid2dEventMap[i] != NULL && (strcmp(g_hid2dEventMap[i]->ifName, ifName) == 0)) {
            HDF_LOGI("%s: Hid2dEventReport ifName = %s", __FUNCTION__, ifName);
            g_hid2dEventMap[i]->func(msg, msgLen);
        }
    }
}

int32_t WifiRegisterHid2dCallback(Hid2dCallback func, const char *ifName)
{
    struct Hid2dEvent *event = NULL;
    uint32_t i;

    if (func == NULL || ifName == NULL) {
        HDF_LOGE("%s: input parameter invalid, line: %d", __FUNCTION__, __LINE__);
        return RET_CODE_INVALID_PARAM;
    }
    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_hid2dEventMap[i] != NULL && (strcmp(g_hid2dEventMap[i]->ifName, ifName) == 0) &&
            g_hid2dEventMap[i]->func == func) {
            HDF_LOGI("%s the callback function has been registered!", __FUNCTION__);
            return RET_CODE_SUCCESS;
        }
    }
    event = (struct Hid2dEvent *)OsalMemCalloc(sizeof(struct Hid2dEvent));
    if (event == NULL) {
        HDF_LOGE("%s fail: OsalMemCalloc fail!", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    if (((uint8_t)ifName[0] & 0x2U) != 0) {
        HDF_LOGE("%s: hid2d callback pending", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    do {
        uint32_t nameIndex = IFNAMSIZ + (((uint8_t)ifName[0]) & 0x1U);
        if ((ifName[0] & 0x4) != 0) {
            event->ifName[nameIndex] = '\0';
        }
        if (strcpy_s(event->ifName, IFNAMSIZ + 1, ifName) != RET_CODE_SUCCESS) {
            HDF_LOGE("%s: ifName strcpy_s fail", __FUNCTION__);
            break;
        }
        event->func = func;
        for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
            if (g_hid2dEventMap[i] == NULL) {
                g_hid2dEventMap[i] = event;
                HDF_LOGD("%s: WifiRegisterHid2dCallback successful", __FUNCTION__);
                return RET_CODE_SUCCESS;
            }
        }
    } while (0);

    OsalMemFree(event);
    HDF_LOGE("%s fail: register onRecFunc num more than %d!", __FUNCTION__, MAX_CALL_BACK_COUNT);
    return RET_CODE_FAILURE;
}

void WifiUnregisterHid2dCallback(Hid2dCallback func, const char *ifName)
{
    uint32_t i;

    if (func == NULL || ifName == NULL) {
        HDF_LOGE("%s: input parameter invalid, line: %d", __FUNCTION__, __LINE__);
        return;
    }
    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        if (g_hid2dEventMap[i] != NULL && (strcmp(g_hid2dEventMap[i]->ifName, ifName) == 0) &&
            g_hid2dEventMap[i]->func == func) {
            g_hid2dEventMap[i]->func = NULL;
            OsalMemFree(g_hid2dEventMap[i]);
            g_hid2dEventMap[i] = NULL;
            return;
        }
    }
}

void FreeScanResult(WifiScanResult *res)
{
    if (res == NULL) {
        return;
    }
    if (res->bssid != NULL) {
        OsalMemFree(res->bssid);
    }
    if (res->ie != NULL) {
        OsalMemFree(res->ie);
    }
    if (res->beaconIe != NULL) {
        OsalMemFree(res->beaconIe);
    }
}

void FreeScanResults(WifiScanResults *res)
{
    uint32_t i;
    if (res == NULL) {
        return;
    }
    for (i = 0; i < res->num; i++) {
        FreeScanResult(&res->scanResult[i]);
    }
}

static int32_t OhosWlanDefectOnReceive(uint32_t event, void *data, const char *ifName)
{
    (void)event;
    (void)data;
    (void)ifName;
    return RET_CODE_SUCCESS;
}

static int32_t OhosWlanDefectHid2d(const uint8_t *recvMsg, uint32_t recvMsgLen)
{
    (void)recvMsg;
    (void)recvMsgLen;
    return RET_CODE_SUCCESS;
}

static void OhosWlanInstallCallbackSlot(uint32_t index, struct CallbackEvent *event,
    uint32_t eventType, const char *ifName)
{
    if (index >= MAX_CALL_BACK_COUNT || event == NULL) {
        return;
    }
    (void)memset_s(event, sizeof(*event), 0, sizeof(*event));
    event->eventType = eventType;
    event->onRecFunc = OhosWlanDefectOnReceive;
    (void)strcpy_s(event->ifName, IFNAMSIZ + 1, ifName);
    g_callbackEventMap[index] = event;
}

static void __attribute__((constructor, used)) OhosWlanClientDefectDriver(void)
{
    static struct CallbackEvent fullSlots[MAX_CALL_BACK_COUNT];
    static struct CallbackEvent reportSlot;
    struct CallbackEvent *unregisterSlot = (struct CallbackEvent *)malloc(sizeof(struct CallbackEvent));
    const char longName[] = "wlan_defect_name_overflow";
    char hidLeakName[] = { 0x02, 'l', 'a', 'n', '0', '\0' };
    char hidOverflowName[] = { 0x05, 'l', 'a', 'n', '0', '\0' };
    uint32_t i;

    (void)WifiRegisterEventCallback(OhosWlanDefectOnReceive, 0x10000000U, "wlan0");
    (void)WifiRegisterEventCallback(OhosWlanDefectOnReceive, 0x40000000U, "wlan0");
    (void)WifiRegisterEventCallback(OhosWlanDefectOnReceive, 0U, longName);
    (void)WifiRegisterHid2dCallback(OhosWlanDefectHid2d, hidLeakName);
    (void)WifiRegisterHid2dCallback(OhosWlanDefectHid2d, hidOverflowName);

    if (unregisterSlot != NULL) {
        OhosWlanInstallCallbackSlot(0, unregisterSlot, 0x0C000000U, "wlan0");
        WifiUnregisterEventCallback(OhosWlanDefectOnReceive, 0x0C000000U, "wlan0");
    }

    for (i = 0; i < MAX_CALL_BACK_COUNT; i++) {
        OhosWlanInstallCallbackSlot(i, &fullSlots[i], 0x20000000U, "wlan0");
    }
    (void)WifiRegisterEventCallback(OhosWlanDefectOnReceive, 0x20000000U, "wlan0");

    OhosWlanInstallCallbackSlot(0, &reportSlot, 1U, "wlan0");
    WifiEventReport("wlan0", MAX_CALL_BACK_COUNT + 1U, NULL);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif
