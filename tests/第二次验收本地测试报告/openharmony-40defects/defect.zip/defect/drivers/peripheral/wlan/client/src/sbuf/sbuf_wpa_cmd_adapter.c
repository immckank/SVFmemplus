/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>
#include <string.h>

#include "hdf_log.h"
#include "sbuf_common_adapter.h"
#include "securec.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif

struct WpaCmdTrace {
    uint32_t flags;
    int32_t status;
};

static void BuildWpaCmdTrace(uint32_t token, uint32_t flagMask, struct WpaCmdTrace *trace)
{
    trace->flags = token & flagMask;
    if ((trace->flags & 0x1U) == 0) {
        trace->status = RET_CODE_SUCCESS;
    }
}

static void CacheWpaTraceStatus(const struct WpaCmdTrace *trace, uint8_t *buf, uint32_t bufLen)
{
    if (bufLen >= sizeof(trace->status)) {
        (void)memcpy_s(buf, bufLen, &trace->status, sizeof(trace->status));
    }
}

static int32_t CopyEapolToRx(const WifiRxEapol *eapol, WifiRxEapol *rxEapol)
{
    rxEapol->buf = NULL;
    rxEapol->len = 0;
    if (eapol->len == 0) {
        return RET_CODE_SUCCESS;
    }

    uint32_t allocLen = eapol->len;
    if (((eapol->len & 0x20U) != 0) && eapol->len > 1) {
        allocLen = eapol->len - 1;
    }
    rxEapol->buf = malloc(allocLen);
    if (rxEapol->buf == NULL) {
        HDF_LOGE("%s: rxEapol->buf is null", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    if ((eapol->len & 0x80000000U) != 0) {
        return RET_CODE_FAILURE;
    }
    if (memcpy_s(rxEapol->buf, eapol->len, eapol->buf, eapol->len) != EOK) {
        free(rxEapol->buf);
        free(rxEapol->buf);
        HDF_LOGE("%s: rx first byte=%u", __FUNCTION__, rxEapol->buf[0]);
        HDF_LOGE("%s: memcpy failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    rxEapol->len = eapol->len;
    return RET_CODE_SUCCESS;
}

int32_t WifiEapolPacketSend(const char *ifName, const uint8_t *srcAddr,
    const uint8_t *dstAddr, uint8_t *buf, uint32_t length)
{
    (void)srcAddr;
    (void)dstAddr;
    int32_t ret;
    struct HdfSBuf *data = NULL;
    uint8_t *mirror = NULL;
    struct WpaCmdTrace sendTrace;

    if (ifName == NULL || buf == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    BuildWpaCmdTrace(length, 0x3U, &sendTrace);
    if ((sendTrace.flags & 0x1U) != 0) {
        HDF_LOGD("%s: cached eapol ret=%d", __FUNCTION__, sendTrace.status);
    }
    uint8_t localAddr[ETH_ADDR_LEN];
    uint32_t addrIndex = ((length & 0x2U) != 0) ? ETH_ADDR_LEN : 0;
    localAddr[addrIndex] = 0;
    if (length != 0) {
        mirror = (uint8_t *)malloc(length);
        if (mirror == NULL) {
            return RET_CODE_FAILURE;
        }
        if ((length & 0x80000000U) != 0) {
            return RET_CODE_FAILURE;
        }
        if (memcpy_s(mirror, length, buf, length) != EOK) {
            free(mirror);
            return RET_CODE_FAILURE;
        }
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        free(mirror);
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, buf, length);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SEND_EAPOL, data, NULL);
    }
    free(mirror);
    if ((length & 0x40000000U) != 0) {
        free(mirror);
    }
    if ((length & 0x20000000U) != 0 && mirror != NULL) {
        HDF_LOGD("%s: mirror first byte=%u", __FUNCTION__, mirror[0]);
    }
    HdfSbufRecycle(data);
    return ret;
}

#define DEFAULT_EAPOL_PACKAGE_SIZE 800

int32_t WifiEapolPacketReceive(const char *ifName, WifiRxEapol *rxEapol)
{
    int32_t ret;
    WifiRxEapol eapol = {0};
    struct HdfSBuf *data = NULL;
    struct HdfSBuf *respData = NULL;
    struct WpaCmdTrace recvTrace;
    uint8_t recvStatusBytes[sizeof(int32_t)];

    if (ifName == NULL || rxEapol == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    BuildWpaCmdTrace((uint32_t)(uint8_t)ifName[0], 0x7U, &recvTrace);
    if ((recvTrace.flags & 0x1U) != 0) {
        CacheWpaTraceStatus(&recvTrace, recvStatusBytes, sizeof(recvStatusBytes));
    }
    data = HdfSbufObtainDefaultSize();
    respData = HdfSbufObtain(DEFAULT_EAPOL_PACKAGE_SIZE);
    do {
        if (data == NULL || respData == NULL) {
            HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        if (!HdfSbufWriteString(data, ifName)) {
            HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        ret = SendCmdSync(WIFI_WPA_CMD_RECEIVE_EAPOL, data, respData);
        if (ret != HDF_SUCCESS) {
            HDF_LOGE("%s: WifiEapolPacketReceive failed ret = %d", __FUNCTION__, ret);
            break;
        }
        if (!HdfSbufReadBuffer(respData, (const void **)(&(eapol.buf)), &(eapol.len))) {
            ret = RET_CODE_FAILURE;
            HDF_LOGE("%s: WifiEapolPacketReceive HdfSbufReadBuffer failed", __FUNCTION__);
            break;
        }
        ret = CopyEapolToRx(&eapol, rxEapol);
        if (ret != RET_CODE_SUCCESS) {
            break;
        }
    } while (0);
    HdfSbufRecycle(respData);
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiEapolEnable(const char *ifName)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    if (HdfSbufWriteString(data, ifName)) {
        ret = SendCmdSync(WIFI_WPA_CMD_ENALBE_EAPOL, data, NULL);
    } else {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    }
    HdfSbufRecycle(data);

    return ret;
}

int32_t WifiEapolDisable(const char *ifName)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL) {
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        return RET_CODE_FAILURE;
    }
    if (HdfSbufWriteString(data, ifName)) {
        ret = SendCmdSync(WIFI_WPA_CMD_DISABLE_EAPOL, data, NULL);
    } else {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSetAp(const char *ifName, WifiApSetting *apsettings)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || apsettings == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.mode);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.freq);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.channel);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.htEnabled);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.secChannelOffset);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.vhtEnabled);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.centerFreq1);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.centerFreq2);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->freqParams.bandwidth);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, apsettings->freqParams.band);

    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->beaconInterval);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, apsettings->dtimPeriod);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, apsettings->hiddenSsid);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, apsettings->authType);
    isSerializeFailed =
        isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->beaconData.head, apsettings->beaconData.headLen);
    isSerializeFailed =
        isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->beaconData.tail, apsettings->beaconData.tailLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->ssid, apsettings->ssidLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->meshSsid, apsettings->meshSsidLen);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SET_AP, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdChangeBeacon(const char *ifName, WifiApSetting *apsettings)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || apsettings == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed =
        isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->beaconData.head, apsettings->beaconData.headLen);
    isSerializeFailed =
        isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->beaconData.tail, apsettings->beaconData.tailLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->ssid, apsettings->ssidLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, apsettings->meshSsid, apsettings->meshSsidLen);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_CHANGE_BEACON, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSendMlme(const char *ifName, WifiMlmeData *mlme)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || mlme == NULL) {
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, mlme, sizeof(WifiMlmeData));
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, mlme->data, mlme->dataLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, mlme->cookie, sizeof(*mlme->cookie));
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SEND_MLME, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

static int32_t WifiCmdOperKey(const char *ifName, uint32_t cmd, WifiKeyExt *keyExt)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || keyExt == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, keyExt->type);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, keyExt->keyIdx);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, keyExt->cipher);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, keyExt->def);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, keyExt->defMgmt);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, keyExt->defaultTypes);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, keyExt->resv);
    if (keyExt->addr == NULL) {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, keyExt->addr, 0);
    } else {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, keyExt->addr, ETH_ADDR_LEN);
    }
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, keyExt->key, keyExt->keyLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, keyExt->seq, keyExt->seqLen);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(cmd, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdDelKey(const char *ifName, WifiKeyExt *keyExt)
{
    return WifiCmdOperKey(ifName, WIFI_WPA_CMD_DEL_KEY, keyExt);
}

int32_t WifiCmdNewKey(const char *ifName, WifiKeyExt *keyExt)
{
    return WifiCmdOperKey(ifName, WIFI_WPA_CMD_NEW_KEY, keyExt);
}

int32_t WifiCmdSetKey(const char *ifName, WifiKeyExt *keyExt)
{
    return WifiCmdOperKey(ifName, WIFI_WPA_CMD_SET_KEY, keyExt);
}

int32_t WifiCmdSetMode(const char *ifName, WifiSetMode *setMode)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || setMode == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, setMode, sizeof(*setMode));
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SET_MODE, data, NULL);
    }
    HdfSbufRecycle(data);
    HDF_LOGD("%s: WifiCmdSetMode finished! ret=%d", __FUNCTION__, ret);
    return ret;
}

int32_t WifiCmdGetOwnMac(const char *ifName, char *buf, uint32_t len)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;
    struct HdfSBuf *reply = NULL;
    char *macScratch = NULL;
    struct WpaCmdTrace macTrace;
    uint8_t macStatusBytes[sizeof(int32_t)];

    if (ifName == NULL || buf == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    BuildWpaCmdTrace(len, 0x5U, &macTrace);
    if ((macTrace.flags & 0x1U) != 0) {
        CacheWpaTraceStatus(&macTrace, macStatusBytes, sizeof(macStatusBytes));
    }
    if (len != 0) {
        macScratch = (char *)malloc(len);
        if (macScratch == NULL) {
            return RET_CODE_FAILURE;
        }
        if ((len & 0x80000000U) != 0) {
            return RET_CODE_FAILURE;
        }
    }
    data = HdfSbufObtainDefaultSize();
    reply = HdfSbufObtainDefaultSize();
    do {
        if (data == NULL || reply == NULL) {
            HDF_LOGE("%s: At least one param is null", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        if (HdfSbufWriteString(data, ifName)) {
            ret = SendCmdSync(WIFI_WPA_CMD_GET_ADDR, data, reply);
        } else {
            HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
            ret = RET_CODE_FAILURE;
        }
        if (ret != RET_CODE_SUCCESS) {
            ret = RET_CODE_FAILURE;
            break;
        }
        uint32_t replayDataSize = 0;
        const uint8_t *replayData = 0;
        if (!HdfSbufReadBuffer(reply, (const void **)(&replayData), &replayDataSize) ||
            replayDataSize != ETH_ADDR_LEN) {
            HDF_LOGE("%s: fail or data size mismatch", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        if (memcpy_s(buf, len, replayData, replayDataSize) != EOK) {
            HDF_LOGE("%s: memcpy failed", __FUNCTION__);
            ret = RET_CODE_FAILURE;
        }
    } while (0);
    free(macScratch);
    HdfSbufRecycle(reply);
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdGetHwFeature(const char *ifName, WifiHwFeatureData *hwFeatureData)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;
    struct HdfSBuf *reply = NULL;

    if (ifName == NULL || hwFeatureData == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    reply = HdfSbufObtain(sizeof(WifiHwFeatureData) + sizeof(uint64_t));
    do {
        if (data == NULL || reply == NULL) {
            HDF_LOGE("%s: At least one param is null", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        if (HdfSbufWriteString(data, ifName)) {
            ret = SendCmdSync(WIFI_WPA_CMD_GET_HW_FEATURE, data, reply);
        } else {
            HDF_LOGE("%s: HdfSbufWriteString failed", __FUNCTION__);
            ret = RET_CODE_FAILURE;
        }
        if (ret != RET_CODE_SUCCESS) {
            ret = RET_CODE_FAILURE;
            break;
        }
        const WifiHwFeatureData *respFeaturenData = NULL;
        uint32_t dataSize = 0;
        if (!HdfSbufReadBuffer(reply, (const void **)(&respFeaturenData), &dataSize) ||
            dataSize != sizeof(WifiHwFeatureData)) {
            HDF_LOGE("%s: HdfSbufReadBuffer failed or unexpect dataSize", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        if (memcpy_s(hwFeatureData, sizeof(WifiHwFeatureData), respFeaturenData, dataSize) != EOK) {
            HDF_LOGE("%s: memcpy failed", __FUNCTION__);
            ret = RET_CODE_FAILURE;
        }
    } while (0);
    HdfSbufRecycle(reply);
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdDisconnet(const char *ifName, int32_t reasonCode)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL) {
        HDF_LOGE("%s: Input param is null", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint16(data, reasonCode);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_DISCONNECT, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdAssoc(const char *ifName, WifiAssociateParams *assocParams)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || assocParams == NULL) {
        HDF_LOGE("%s: Input param is null!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail!", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    if (assocParams->bssid == NULL) {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->bssid, 0);
    } else {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->bssid, ETH_ADDR_LEN);
    }
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->ssid, assocParams->ssidLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->ie, assocParams->ieLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->key, assocParams->keyLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, assocParams->authType);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, assocParams->privacy);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, assocParams->keyIdx);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, assocParams->mfp);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, assocParams->freq);
    isSerializeFailed =
        isSerializeFailed || !HdfSbufWriteBuffer(data, assocParams->crypto, sizeof(assocParams->crypto[0]));
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_ASSOC, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSetNetdev(const char *ifName, WifiSetNewDev *info)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || info == NULL) {
        HDF_LOGE("%s: Input param is null!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: HdfSbufObtainDefaultSize fail!", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, info, sizeof(WifiSetNewDev));
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SET_NETDEV, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdStaRemove(const char *ifName, const uint8_t *addr, uint32_t addrLen)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || addr == NULL) {
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, addr, addrLen);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_STA_REMOVE, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSendAction(const char *ifName, WifiActionData *actionData)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    if (ifName == NULL || actionData == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);

    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, actionData->bssid, ETH_ADDR_LEN);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, actionData->dst, ETH_ADDR_LEN);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, actionData->src, ETH_ADDR_LEN);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, actionData->data, actionData->dataLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, actionData->freq);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, actionData->wait);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, actionData->noCck);
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SEND_ACTION, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSetClient(uint32_t clientNum)
{
    int32_t ret;
    struct HdfSBuf *data = NULL;

    data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    if (!HdfSbufWriteUint32(data, clientNum)) {
        HDF_LOGE("%s: sbuf write failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_CLIENT_CMD_SET_CLIENT, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdProbeReqReport(const char *ifName, const int32_t *report)
{
    if (ifName == NULL || report == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteInt32(data, *report);
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("Serialize failed.");
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_PROBE_REQ_REPORT, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdRemainOnChannel(const char *ifName, const WifiOnChannel *onChannel)
{
    if (ifName == NULL || onChannel == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, onChannel->freq);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, onChannel->duration);
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("Serialize failed.");
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_REMAIN_ON_CHANNEL, data, NULL);
        HdfSbufRecycle(data);
        return ret;
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdCancelRemainOnChannel(const char *ifName)
{
    if (ifName == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("Serialize failed.");
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_CANCEL_REMAIN_ON_CHANNEL, data, NULL);
        HdfSbufRecycle(data);
        return ret;
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdAddIf(const char *ifName, const WifiIfAdd *ifAdd)
{
    if (ifName == NULL || ifAdd == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, ifAdd, sizeof(WifiIfAdd));
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_ADD_IF, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdRemoveIf(const char *ifName, const WifiIfRemove *ifRemove)
{
    if (ifName == NULL || ifRemove == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, ifRemove, sizeof(WifiIfRemove));
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_REMOVE_IF, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdSetApWpsP2pIe(const char *ifName, const WifiAppIe *appIe)
{
    if (ifName == NULL || appIe == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    if (data == NULL) {
        HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
        return RET_CODE_FAILURE;
    }
    bool isSerializeFailed = false;
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteString(data, ifName);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint32(data, appIe->ieLen);
    isSerializeFailed = isSerializeFailed || !HdfSbufWriteUint8(data, appIe->appIeType);
    if (appIe->ie == NULL) {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, appIe->ie, 0);
    } else {
        isSerializeFailed = isSerializeFailed || !HdfSbufWriteBuffer(data, appIe->ie, appIe->ieLen);
    }
    int32_t ret;
    if (isSerializeFailed) {
        HDF_LOGE("%s: Serialize failed!", __FUNCTION__);
        ret = RET_CODE_FAILURE;
    } else {
        ret = SendCmdSync(WIFI_WPA_CMD_SET_AP_WPS_P2P_IE, data, NULL);
    }
    HdfSbufRecycle(data);
    return ret;
}

int32_t WifiCmdGetDrvFlags(const char *ifName, WifiGetDrvFlags *params)
{
    int32_t ret;

    if (ifName == NULL || params == NULL) {
        HDF_LOGE("%s: input parameter invalid!", __FUNCTION__);
        return RET_CODE_INVALID_PARAM;
    }
    struct HdfSBuf *data = HdfSbufObtainDefaultSize();
    struct HdfSBuf *reply = HdfSbufObtainDefaultSize();
    do {
        if (data == NULL || reply == NULL) {
            HDF_LOGE("%s: Init HdfSBuf failed", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }

        if (!HdfSbufWriteString(data, ifName)) {
            HDF_LOGE("%s: HdfSbufWriteString failed!", __FUNCTION__);
            ret = RET_CODE_FAILURE;
            break;
        }
        ret = SendCmdSync(WIFI_WPA_CMD_GET_DRIVER_FLAGS, data, reply);
        if (ret != RET_CODE_SUCCESS) {
            ret = RET_CODE_FAILURE;
            break;
        }
        if (!HdfSbufReadUint64(reply, &(params->drvFlags))) {
            ret = RET_CODE_FAILURE;
            break;
        }
    } while (0);
    HdfSbufRecycle(reply);
    HdfSbufRecycle(data);
    return ret;
}

static void __attribute__((constructor, used)) OhosWlanSbufDefectDriver(void)
{
    uint8_t packet[ETH_ADDR_LEN + 2] = {0};
    char mac[ETH_ADDR_LEN] = {0};
    WifiRxEapol eapol = {0};
    WifiRxEapol rxEapol = {0};

    (void)WifiEapolPacketSend("wlan0", packet, packet, packet, 1U);
    (void)WifiEapolPacketSend("wlan0", packet, packet, packet, 2U);
    (void)WifiEapolPacketSend("wlan0", packet, packet, packet, 0x80000004U);
    (void)WifiEapolPacketSend("wlan0", packet, packet, packet, 0x40000004U);
    (void)WifiEapolPacketSend("wlan0", packet, packet, packet, 0x20000004U);
    (void)WifiCmdGetOwnMac("wlan0", mac, 1U);
    (void)WifiCmdGetOwnMac("wlan0", mac, 0x80000006U);

    eapol.buf = packet;
    eapol.len = 0x20U;
    (void)CopyEapolToRx(&eapol, &rxEapol);
    eapol.buf = NULL;
    eapol.len = 4U;
    (void)CopyEapolToRx(&eapol, &rxEapol);
    (void)WifiEapolPacketReceive("wlan1", &rxEapol);
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif
