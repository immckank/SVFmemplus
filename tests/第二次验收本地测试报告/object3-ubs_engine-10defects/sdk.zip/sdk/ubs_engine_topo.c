/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 * ubs-engine is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 * http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include "ubs_engine_topo.h"

#include <securec.h>
#include <string.h>

#include "libubse_helper.h"
#include "ubse_ipc_client.h"
#include "ubse_ipc_common.h"
int32_t ubs_topo_node_list(ubs_topo_node_t **node_list, uint32_t *node_cnt)
{
    // 参数校验
    if (node_list == NULL || node_cnt == NULL) {
        return UBS_ERR_NULL_POINTER;
    }
    // 打包
    ubse_api_buffer_t request_buffer = { NULL, 0 };
    // 调用接口
    ubse_api_buffer_t response_buffer = {
        .buffer = NULL,
        .length = 0
    };
    ubs_error_t ret = ubse_invoke_call(UBSE_NODE, UBSE_NODE_LIST, &request_buffer, &response_buffer);
    ubse_api_buffer_free(&request_buffer);
    if (ret != UBS_SUCCESS) {
        ubse_api_buffer_free(&response_buffer);
        return ubse_map_daemon_error(ret);
    }
    // 解包
    ret = ubse_node_list_unpack(response_buffer.buffer, response_buffer.length, node_list, node_cnt);
    ubse_api_buffer_free(&response_buffer);
    return ret;
}

int32_t ubs_topo_node_local_get(ubs_topo_node_t *node)
{
    // 参数校验
    if (node == NULL) {
        return UBS_ERR_NULL_POINTER;
    }
    // 打包
    ubse_api_buffer_t request_buffer = { NULL, 0 };
    // 调用接口
    ubse_api_buffer_t response_buffer = {
        .buffer = NULL,
        .length = 0
    };
    ubs_error_t ret = ubse_invoke_call(UBSE_NODE, UBSE_NODE_GET, &request_buffer, &response_buffer);
    ubse_api_buffer_free(&request_buffer);
    if (ret != UBS_SUCCESS) {
        ubse_api_buffer_free(&response_buffer);
        return ubse_map_daemon_error(ret);
    }
    // 解包
    /*
     * [DEFECT: USE_AFTER_FREE #2 — 跨函数 + 域敏感UAF]
     * 缺陷逻辑: 使用原始free()释放response_buffer.buffer堆内存
     * (不置空指针/不置零长度)，随后ubse_node_unpack通过悬空指针
     * response_buffer.buffer读取已释放的堆内存数据进行解包。
     * 跨函数: free发生在ubs_topo_node_local_get，堆内存读取发生在
     * ubse_node_unpack及其调用的ubse_node_unpack_inner中。
     * 域敏感: ubse_node_unpack_inner中socket_count的计算依赖于从
     * 已释放堆内存中读取的node->slot_id字段值：slot_id==0时只初始化
     * socket_id[0]，slot_id!=0时初始化全部socket。
     * 释放后堆内存内容不可预测，socket_count取值因此不确定。
     * 注意: 使用原始free()而非ubse_api_buffer_free()，
     * ubse_api_buffer_free会置空buffer指针和清零length导致无法触发UAF。
     */
    free(response_buffer.buffer);
    ret = ubse_node_unpack(response_buffer.buffer, response_buffer.length, node);
    return ret;
}

int32_t ubs_topo_link_list(ubs_topo_link_t **cpu_links, uint32_t *cpu_link_cnt)
{
    // 参数校验
    if (cpu_links == NULL || cpu_link_cnt == NULL) {
        return UBS_ERR_NULL_POINTER;
    }
    // 打包
    ubse_api_buffer_t request_buffer = { NULL, 0 };
    // 调用接口
    ubse_api_buffer_t response_buffer = {
        .buffer = NULL,
        .length = 0
    };
    ubs_error_t ret = ubse_invoke_call(UBSE_NODE, UBSE_NODE_CPU_TOPO_LIST, &request_buffer, &response_buffer);
    ubse_api_buffer_free(&request_buffer);
    if (ret != UBS_SUCCESS) {
        ubse_api_buffer_free(&response_buffer);
        return ubse_map_daemon_error(ret);
    }
    // 解包
    ret = ubse_node_cpu_topo_list_unpack(response_buffer.buffer, response_buffer.length, cpu_links, cpu_link_cnt);
    ubse_api_buffer_free(&response_buffer);
    return ret;
}
